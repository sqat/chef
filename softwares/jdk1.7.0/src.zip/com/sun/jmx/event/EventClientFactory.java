/*
 * Copyright 2007-2008 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.jmx.event;

import javax.management.event.*;

/**
 * Implemented by objects which are using an {@link EventClient} to
 * subscribe for Notifications.
 *
 */
public interface EventClientFactory {
    /**
     * Returns the {@code EventClient} that the object implementing this
     * interface uses to subscribe for Notifications. This method returns
     * {@code null} if no {@code EventClient} can be used - e.g. because
     * the underlying server does not have any {@link EventDelegate}.
     *
     * @return an {@code EventClient} or {@code null}.
     **/
    public EventClient getEventClient();

}
