/*
 * Copyright 2007-2008 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.jmx.event;

import com.sun.jmx.mbeanserver.GetPropertyAction;
import com.sun.jmx.remote.util.ClassLogger;
import java.security.AccessController;
import javax.management.event.EventClient;

/**
 *
 * @author sjiang
 */
public class EventParams {
    public static final String DEFAULT_LEASE_TIMEOUT =
            "com.sun.event.lease.time";


    @SuppressWarnings("cast") // cast for jdk 1.5
    public static long getLeaseTimeout() {
        long timeout = EventClient.DEFAULT_REQUESTED_LEASE_TIME;
        try {
            final GetPropertyAction act =
                  new GetPropertyAction(DEFAULT_LEASE_TIMEOUT);
            final String s = (String)AccessController.doPrivileged(act);
            if (s != null) {
                timeout = Long.parseLong(s);
            }
        } catch (RuntimeException e) {
            logger.fine("getLeaseTimeout", "exception getting property", e);
        }

        return timeout;
    }

    /** Creates a new instance of EventParams */
    private EventParams() {
    }

    private static final ClassLogger logger =
            new ClassLogger("javax.management.event", "EventParams");
}
