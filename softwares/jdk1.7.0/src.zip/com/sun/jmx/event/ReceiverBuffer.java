/*
 * Copyright 2007-2008 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.jmx.event;

import com.sun.jmx.remote.util.ClassLogger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.management.remote.NotificationResult;
import javax.management.remote.TargetedNotification;


public class ReceiverBuffer {
    public void addNotifs(NotificationResult nr) {
        if (nr == null) {
            return;
        }

        TargetedNotification[] tns = nr.getTargetedNotifications();

        if (logger.traceOn()) {
            logger.trace("addNotifs", "" + tns.length);
        }

        long impliedStart = nr.getEarliestSequenceNumber();
        final long missed = impliedStart - start;
        start = nr.getNextSequenceNumber();

        if (missed > 0) {
            if (logger.traceOn()) {
                logger.trace("addNotifs",
                        "lost: "+missed);
            }

            lost += missed;
        }

        Collections.addAll(notifList, nr.getTargetedNotifications());
    }

    public TargetedNotification[] removeNotifs() {
        if (logger.traceOn()) {
            logger.trace("removeNotifs", String.valueOf(notifList.size()));
        }

        if (notifList.size() == 0) {
            return null;
        }

        TargetedNotification[] ret = notifList.toArray(
                new TargetedNotification[]{});
        notifList.clear();

        return ret;
    }

    public int size() {
        return notifList.size();
    }

    public int removeLost() {
        int ret = lost;
        lost = 0;
        return ret;
    }

    private List<TargetedNotification> notifList
            = new ArrayList<TargetedNotification>();
    private long start = 0;
    private int lost = 0;

    private static final ClassLogger logger =
            new ClassLogger("javax.management.event", "ReceiverBuffer");
}
