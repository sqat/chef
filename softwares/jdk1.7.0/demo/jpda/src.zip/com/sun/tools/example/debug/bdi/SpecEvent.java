/*
 * Copyright 1999 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.bdi;

import java.util.EventObject;

import com.sun.jdi.request.EventRequest;

public class SpecEvent extends EventObject {

    private EventRequestSpec eventRequestSpec;

    public SpecEvent(EventRequestSpec eventRequestSpec) {
        super(eventRequestSpec.specs);
        this.eventRequestSpec = eventRequestSpec;
    }

    public EventRequestSpec getEventRequestSpec() {
        return eventRequestSpec;
    }

    public EventRequest getEventRequest() {
        return eventRequestSpec.getEventRequest();
    }
}
