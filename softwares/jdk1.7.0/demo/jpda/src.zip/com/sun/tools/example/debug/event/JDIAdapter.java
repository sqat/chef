/*
 * Copyright 1999 Sun Microsystems, Inc.  All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.event;

/**
 * The adapter which receives JDI event sets. The methods in this
 * class are empty; this class is provided as a convenience for
 * easily creating listeners by extending this class and overriding
 * only the methods of interest.
 */
public class JDIAdapter implements JDIListener {

    public void accessWatchpoint(AccessWatchpointEventSet e) {
    }

    public void classPrepare(ClassPrepareEventSet e)  {
    }

    public void classUnload(ClassUnloadEventSet e)  {
    }

    public void exception(ExceptionEventSet e)  {
    }

    public void locationTrigger(LocationTriggerEventSet e)  {
    }

    public void modificationWatchpoint(ModificationWatchpointEventSet e)  {
    }

    public void threadDeath(ThreadDeathEventSet e)  {
    }

    public void threadStart(ThreadStartEventSet e)  {
    }

    public void vmDeath(VMDeathEventSet e)  {
    }

    public void vmDisconnect(VMDisconnectEventSet e)  {
    }

    public void vmStart(VMStartEventSet e)  {
    }

}
